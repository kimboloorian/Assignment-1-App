//
//  ViewController.swift
//  Assignment1
//
//  Created by kb15abp on 05/11/2018.
//  Copyright © 2018 KBStudios. All rights reserved.
//

import UIKit

protocol subviewdelegate {
    func changesomething()
}

class ViewController: UIViewController, subviewdelegate {
    
    
    @IBOutlet weak var treeImage: UIImageView!

    @IBOutlet weak var roadImage: UIImageView!
    
    @IBOutlet weak var cloudImage: UIImageView!
    @IBOutlet weak var cloud2Image: UIImageView!
    
    @IBOutlet weak var planeImage: DraggedImageView!
    
    var birdAnimator: UIDynamicAnimator!
    var birdViewBehavior: UIDynamicItemBehavior!
    
    var delayArray = [0, 3, 6, 9, 12, 15, 18]
    var delayViewArray: [UIImageView] = []
    
    //assign variables to standard libraries for animation, gravity, behavior, etc.
    var dynamicAnimator: UIDynamicAnimator!
    var collisionBehavior: UICollisionBehavior!
    var gravityBehavior: UIGravityBehavior!
    var dynamicBehavior: UIDynamicItemBehavior!
    
    //2
    var birdAnimator2: UIDynamicAnimator!
    var birdViewBehavior2: UIDynamicItemBehavior!
    
    var delayArray2 = [0, 3, 6, 9, 12, 15, 18]
    var delayViewArray2: [UIImageView] = []
    
    let W = UIScreen.main.bounds.width
    let H = UIScreen.main.bounds.height
    
     //reuse of code from previous dragging exercise but with inclusion of barrier and updated boundaries as the object is moved
    func changesomething() {
        collisionBehavior.removeAllBoundaries()
        collisionBehavior.addBoundary(withIdentifier: "barrier" as NSCopying, for: UIBezierPath(rect: planeImage.frame))
    }
    
        

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        
        var imageArrayRoad: [UIImage]!
        
        imageArrayRoad = [UIImage(named: "road1.png")!,
                      UIImage(named: "road2.png")!,
                      UIImage(named: "road3.png")!,
                      UIImage(named: "road4.png")!,
                      UIImage(named: "road5.png")!,
                      UIImage(named: "road6.png")!,
                      UIImage(named: "road7.png")!,
                      UIImage(named: "road8.png")!,
                      UIImage(named: "road9.png")!,
                      UIImage(named: "road10.png")!,
                      UIImage(named: "road11.png")!,
                      UIImage(named: "road12.png")!,
                      UIImage(named: "road13.png")!,
                      UIImage(named: "road14.png")!,
                      UIImage(named: "road15.png")!,
                      UIImage(named: "road16.png")!,
                      UIImage(named: "road17.png")!,
                      UIImage(named: "road18.png")!,
                      UIImage(named: "road19.png")!]
        
        
        roadImage.image = UIImage.animatedImage(with: imageArrayRoad, duration: 1)
        
        self.roadImage.frame.size.width = W
        self.roadImage.frame.size.height = H
        
        var imageArrayTree: [UIImage]!
        
        imageArrayTree = [UIImage(named: "tree1.png")!,
                          UIImage(named: "tree2.png")!,
                          UIImage(named: "tree3.png")!,
                          UIImage(named: "tree4.png")!,
                          UIImage(named: "tree5.png")!,
                          UIImage(named: "tree6.png")!,
                          UIImage(named: "tree7.png")!,
                          UIImage(named: "tree8.png")!,
                          UIImage(named: "tree9.png")!,
                          UIImage(named: "tree10.png")!,
                          UIImage(named: "tree11.png")!,
                          UIImage(named: "tree12.png")!,
                          UIImage(named: "tree13.png")!,
                          UIImage(named: "tree14.png")!,
                          UIImage(named: "tree15.png")!,
                          UIImage(named: "tree16.png")!,
                          UIImage(named: "tree17.png")!,]
        
        treeImage.image = UIImage.animatedImage(with: imageArrayTree, duration: 1)

        self.treeImage.frame.size.width = W
        self.treeImage.frame.size.height = H*0.62
    
        var imageArrayPlane: [UIImage]!
        
        imageArrayPlane = [UIImage(named: "plane1.png")!,
                          UIImage(named: "plane2.png")!,
                          UIImage(named: "plane3.png")!,
                          UIImage(named: "plane4.png")!,
                          UIImage(named: "plane5.png")!,
                          UIImage(named: "plane6.png")!,
                          UIImage(named: "plane7.png")!,
                          UIImage(named: "plane8.png")!,
                          UIImage(named: "plane9.png")!,
                          UIImage(named: "plane10.png")!,
                          UIImage(named: "plane11.png")!,
                          UIImage(named: "plane12.png")!,
                          UIImage(named: "plane13.png")!,
                          UIImage(named: "plane14.png")!,
                          UIImage(named: "plane15.png")!,]
        
        planeImage.image = UIImage.animatedImage(with: imageArrayPlane, duration: 1)
        
       
    
        UIView.animate(withDuration: 60, delay: 0.0, options: [UIViewAnimationOptions.repeat, .curveLinear], animations:
            {
                self.cloudImage.center.x += self.view.bounds.width
                self.cloud2Image.center.x += self.view.bounds.width
    
                
        }, completion: nil
        )
        
        
        
        for index in 0...6 {
            let delay = Double(self.delayArray[index])
            
            let when = DispatchTime.now() + delay
            let random_height = Int(arc4random_uniform(UInt32 (self.H)) + 0);
            
            DispatchQueue.main.asyncAfter(deadline: when) {
                
                let birdView = UIImageView(image: nil)
                
                birdView.frame = CGRect(x: 700, y: random_height, width: 50, height: 50)
                
                self.view.addSubview(birdView)
                
                self.view.bringSubview(toFront: birdView)
                
                self.delayViewArray.append(birdView)
                
                var imageArrayBird: [UIImage]!
                
                imageArrayBird = [UIImage(named: "bird1.png")!,
                                  UIImage(named: "bird2.png")!,
                                  UIImage(named: "bird3.png")!,
                                  UIImage(named: "bird4.png")!,
                                  UIImage(named: "bird5.png")!,
                                  UIImage(named: "bird6.png")!,
                                  UIImage(named: "bird7.png")!,
                                  UIImage(named: "bird8.png")!,
                                  UIImage(named: "bird9.png")!,
                                  UIImage(named: "bird10.png")!,]
                
                birdView.image = UIImage.animatedImage(with: imageArrayBird, duration: 1)
                
                self.birdAnimator = UIDynamicAnimator(referenceView: self.view)
                self.birdViewBehavior = UIDynamicItemBehavior(items: [])
                self.birdAnimator.addBehavior(self.birdViewBehavior)
                
                self.birdViewBehavior.addItem(birdView)
                self.birdViewBehavior.addLinearVelocity(CGPoint(x: -320, y: 0), for: birdView)
                print("top bird \(index) is created")
                
                
                //delegate has been addded to allow for a draggable player plane to interact with other
                //planeImage.mydelegate = self
                
                self.dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
                
                //apply and add gravity to crows
                self.gravityBehavior = UIGravityBehavior(items: [birdView])
                self.dynamicAnimator.addBehavior(self.gravityBehavior)
                
                //apply and add collision to crow objects PLUS make collision occur within the bounds of the screen (dont fall off screen)
                self.collisionBehavior = UICollisionBehavior(items: [birdView])
                self.dynamicAnimator.addBehavior(self.collisionBehavior)
                self.collisionBehavior.translatesReferenceBoundsIntoBoundary = true
                self.collisionBehavior.addBoundary(withIdentifier: "barrier" as NSCopying, for: UIBezierPath(rect: self.planeImage.frame))
                
                //assignment of additional behavior - adds elasticity to the crows to make them bound more realistic
                self.dynamicBehavior = UIDynamicItemBehavior (items: [birdView]);
                self.dynamicBehavior.elasticity = 0.8;
                self.dynamicAnimator.addBehavior(self.dynamicBehavior)
    
    
            }
            
        }
        
        
        for index in 0...6 {
            let delay2 = Double(self.delayArray[index])
            
            let when = DispatchTime.now() + delay2
            let random_height = Int(arc4random_uniform(UInt32 (self.H)) + 0);
            
            DispatchQueue.main.asyncAfter(deadline: when) {
                
                let birdView2 = UIImageView(image: nil)
                
                birdView2.frame = CGRect(x: 700, y: random_height, width: 50, height: 50)
                
                self.view.addSubview(birdView2)
                
                self.view.bringSubview(toFront: birdView2)
                
                self.delayViewArray2.append(birdView2)
                
                var imageArrayBird2: [UIImage]!
                
                imageArrayBird2 = [UIImage(named: "bird1.png")!,
                                   UIImage(named: "bird2.png")!,
                                   UIImage(named: "bird3.png")!,
                                   UIImage(named: "bird4.png")!,
                                   UIImage(named: "bird5.png")!,
                                   UIImage(named: "bird6.png")!,
                                   UIImage(named: "bird7.png")!,
                                   UIImage(named: "bird8.png")!,
                                   UIImage(named: "bird9.png")!,
                                   UIImage(named: "bird10.png")!,]
                
                birdView2.image = UIImage.animatedImage(with: imageArrayBird2, duration: 1)
                
                self.birdAnimator2 = UIDynamicAnimator(referenceView: self.view)
                self.birdViewBehavior2 = UIDynamicItemBehavior(items: [])
                self.birdAnimator2.addBehavior(self.birdViewBehavior2)
                
                self.birdViewBehavior2.addItem(birdView2)
                self.birdViewBehavior2.addLinearVelocity(CGPoint(x: -320, y: 0), for: birdView2)
                print("bottom bird \(index) is created")
            }
            
        
        }
        
   
        
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//
//  ViewController.swift
//  Assignment1
//
//  Created by kb15abp on 05/11/2018.
//  Copyright © 2018 KBStudios. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var treeImage: UIImageView!
    @IBOutlet weak var tree2Image: UIImageView!
    
    @IBOutlet weak var roadImage: UIImageView!
    
    @IBOutlet weak var cloudImage: UIImageView!
    @IBOutlet weak var cloud2Image: UIImageView!
    
    @IBOutlet weak var planeImage: DraggedImageView!
    
    var birdAnimator: UIDynamicAnimator!
    var birdViewBehavior: UIDynamicItemBehavior!
    
 
    let W = UIScreen.main.bounds.width
    let H = UIScreen.main.bounds.height
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        var imageArrayRoad: [UIImage]!
        
        imageArrayRoad = [UIImage(named: "road1.png")!,
                      UIImage(named: "road2.png")!,
                      UIImage(named: "road3.png")!,
                      UIImage(named: "road4.png")!,
                      UIImage(named: "road5.png")!,
                      UIImage(named: "road6.png")!,
                      UIImage(named: "road7.png")!,
                      UIImage(named: "road8.png")!,
                      UIImage(named: "road9.png")!,
                      UIImage(named: "road10.png")!,
                      UIImage(named: "road11.png")!,
                      UIImage(named: "road12.png")!,
                      UIImage(named: "road13.png")!,
                      UIImage(named: "road14.png")!,
                      UIImage(named: "road15.png")!,
                      UIImage(named: "road16.png")!,
                      UIImage(named: "road17.png")!,
                      UIImage(named: "road18.png")!,
                      UIImage(named: "road19.png")!]
        
        
        roadImage.image = UIImage.animatedImage(with: imageArrayRoad, duration: 0.7)
        
        self.roadImage.frame.size.width = W
        self.roadImage.frame.size.height = H
        
        
        var imageArrayPlane: [UIImage]!
        
        imageArrayPlane = [UIImage(named: "plane1.png")!,
                          UIImage(named: "plane2.png")!,
                          UIImage(named: "plane3.png")!,
                          UIImage(named: "plane4.png")!,
                          UIImage(named: "plane5.png")!,
                          UIImage(named: "plane6.png")!,
                          UIImage(named: "plane7.png")!,
                          UIImage(named: "plane8.png")!,
                          UIImage(named: "plane9.png")!,
                          UIImage(named: "plane10.png")!,
                          UIImage(named: "plane11.png")!,
                          UIImage(named: "plane12.png")!,
                          UIImage(named: "plane13.png")!,
                          UIImage(named: "plane14.png")!,
                          UIImage(named: "plane15.png")!,]
        
        
        planeImage.image = UIImage.animatedImage(with: imageArrayPlane, duration: 1)
            
        
            self.treeImage.frame = CGRect(x: 0, y: self.H*0.28, width: self.W*1, height: self.H*0.50)
        //self.view.bringSubview(toFront: treeImage)
       
            self.tree2Image.frame = CGRect(x: 560, y: self.H*0.28, width: self.W*1, height: self.H*0.50)
        //self.view.bringSubview(toFront: tree2Image)

        
        //UIView.animate(withDuration: 30, delay: 0.0, options: [UIViewAnimationOptions.repeat, .curveLinear], animations:
            //{
            
                //self.treeImage.center.x += self.view.bounds.width
                //self.tree2Image.center.x += self.view.bounds.width
                
                
        //}, completion: nil
        //)
        
        
        UIView.animate(withDuration: 12.0, delay: 0.0, options: [.repeat, .curveLinear], animations: {
            self.treeImage.frame = self.treeImage.frame.offsetBy(dx: -1 * self.treeImage.frame.size.width, dy: 0.0)
            self.tree2Image.frame = self.tree2Image.frame.offsetBy(dx: -1 * self.tree2Image.frame.size.width, dy: 0.0)
        }, completion: nil)
        
        
        UIView.animate(withDuration: 60, delay: 0.0, options: [UIViewAnimationOptions.repeat, .curveLinear], animations:
            {
                self.cloudImage.center.x += self.view.bounds.width
                self.cloud2Image.center.x += self.view.bounds.width
    
                
        }, completion: nil
        )
        
        let when = DispatchTime.now() + 2
        DispatchQueue.main.asyncAfter(deadline: when) {
            
            
            
        let birdView = UIImageView(image: nil)
        
        var imageArrayBird: [UIImage]!
        
        imageArrayBird = [UIImage(named: "bird1.png")!,
                          UIImage(named: "bird2.png")!,
                          UIImage(named: "bird3.png")!,
                          UIImage(named: "bird4.png")!,
                          UIImage(named: "bird5.png")!,
                          UIImage(named: "bird6.png")!,
                          UIImage(named: "bird7.png")!,
                          UIImage(named: "bird8.png")!,
                          UIImage(named: "bird9.png")!,
                          UIImage(named: "bird10.png")!,]
        
        birdView.image = UIImage.animatedImage(with: imageArrayBird, duration: 1)
        
            
        self.view.addSubview(birdView)
            
        self.view.bringSubview(toFront: birdView)
            
        //initializing dynamic animator
        self.birdAnimator = UIDynamicAnimator(referenceView: self.view)
        self.birdViewBehavior = UIDynamicItemBehavior(items: [])
        self.birdAnimator.addBehavior(self.birdViewBehavior)
            
            
            var i = 4;
            
            while i >= 0 {
                
                var random_height = Int(arc4random_uniform(UInt32(self.H))) + 0;
                    
                    birdView.frame = CGRect(x: self.W-100, y: self.H, width: 60, height: 60)
                    
                    self.birdViewBehavior.addItem(birdView)
                    
                    self.birdViewBehavior.addLinearVelocity(CGPoint(x: -100, y: 0), for: birdView)
                
                i = i + 1;
                
            }
       // let buffer: UInt32= 100
      //  let randomX = srandomdev(min: buffer, max: UInt32(self.size.width) - buffer)
      //  imageArrayBird?.position = CGPoint(x: CGFloat(randomX), y: self.frame.maxY)
        
      //      assert(min < max)
      //      return CGFloat(arc4random_uniform(max - min)  + min)
        }
        
        
        
       
        
        // Find the width and height of the enclosing view
       // let viewWidth = birdView.superview!.bounds.width
        //let viewHeight = birdView.superview!.bounds.height
        
        // Compute width and height of the area to contain the button's center
      //  let xwidth = viewWidth - birdViewWidth
       // let yheight = viewHeight - birdViewHeight
        
        // Generate a random x and y offset
       //let xoffset = CGFloat(arc4random_uniform(UInt32(xwidth)))
      //let yoffset = CGFloat(arc4random_uniform(UInt32(yheight)))
        
        // Offset the button's center by the random offsets.
      //  birdView.center.x = xoffset + birdViewWidth / 2
      //  birdView.center.y = yoffset + birdViewHeight / 2
        
        
        
        //{ (_) in
        
        //UIView.animate(withDuration: 5, delay: 1, options: [.curveEaseIn], animations: {
         //   birdView.frame.origin.x -= birdView.frame.width}
           // })
            
         //birdView.frane = imageArrayBird[arc4random_uniform(9) + 1]
        //birdView.image = UIImage(named: "bird1.png")!
    
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    
    }
    
        
}


//instead of cgpoint, define new var

//contrain movement into parent bounds
//let halfx= self.bounds.midx)
//max lower case, mo semi colons




